from collections import Counter


class depart:

    def input():
        print("Название| Код отдела")
        f = open('tad1.txt', 'r+')
        print(*f)
        f.close()


class docs:

    def input():
        print("Код документа| Название|Номер| Код вида| Код отдела - отправителя| Код отдела - получателя| Дата регистрации")
        f = open('tad2.txt', 'r+')
        print(*f)
        f.close()


while True:
    print(
        "Выберите таблицу \nВиды документов - 1\nОтделы - 2 \nДокументы - 3 \nКоличество документов по каждому виду - 4\nСлужебные записки планового отдела - 5\nВыход-6")
    tad = int(input())
    if tad == 1:
        while True:
            print("Код вида|название документа")
            f = open('tad.txt', 'r+')
            print(*f)
            break

    elif tad == 2:
        depart.input()
    elif tad == 3:
        docs.input()
    elif tad == 4:
        data = 0
        z = []
        x = []
        with open("tad2.txt", "r") as f:
            data = f.readlines()
        for i in data:
            z.append(i.split(" "))
        for i in z:
            x.append(i[0])
        print("Количество документов по каждому виду\n", Counter(x), '\n')
    elif tad == 5:
        data = 0
        z = []
        x = []
        c = 0
        with open("tad1.txt", "r") as f:
            data = f.readlines()
        for i in data:
            z.append(i.split(" "))
        for i in z:
            x.append(i[1])
        for i in x:
            c = c + int(i)
        print("Служебные записки планового отдела = ", c, '\n')
    elif tad == 6:
        break
